<?php

namespace ContainerPBJpSmu;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder77c12 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer957d2 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties1fa19 = [
        
    ];

    public function getConnection()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getConnection', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getMetadataFactory', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getExpressionBuilder', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'beginTransaction', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getCache', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getCache();
    }

    public function transactional($func)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'transactional', array('func' => $func), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'wrapInTransaction', array('func' => $func), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'commit', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->commit();
    }

    public function rollback()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'rollback', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getClassMetadata', array('className' => $className), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'createQuery', array('dql' => $dql), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'createNamedQuery', array('name' => $name), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'createQueryBuilder', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'flush', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'clear', array('entityName' => $entityName), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->clear($entityName);
    }

    public function close()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'close', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->close();
    }

    public function persist($entity)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'persist', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'remove', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'refresh', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'detach', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'merge', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getRepository', array('entityName' => $entityName), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'contains', array('entity' => $entity), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getEventManager', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getConfiguration', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'isOpen', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getUnitOfWork', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getProxyFactory', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'initializeObject', array('obj' => $obj), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'getFilters', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'isFiltersStateClean', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'hasFilters', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return $this->valueHolder77c12->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer957d2 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHolder77c12) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder77c12 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder77c12->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, '__get', ['name' => $name], $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        if (isset(self::$publicProperties1fa19[$name])) {
            return $this->valueHolder77c12->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder77c12;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder77c12;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder77c12;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder77c12;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, '__isset', array('name' => $name), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder77c12;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder77c12;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, '__unset', array('name' => $name), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder77c12;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder77c12;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, '__clone', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        $this->valueHolder77c12 = clone $this->valueHolder77c12;
    }

    public function __sleep()
    {
        $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, '__sleep', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;

        return array('valueHolder77c12');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer957d2 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer957d2;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer957d2 && ($this->initializer957d2->__invoke($valueHolder77c12, $this, 'initializeProxy', array(), $this->initializer957d2) || 1) && $this->valueHolder77c12 = $valueHolder77c12;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder77c12;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder77c12;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
